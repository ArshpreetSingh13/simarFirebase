import { Login } from "./assets/components/Login"


function App() {


  return (
  <>
    <Login/>
  </>
  )
}

export default App
